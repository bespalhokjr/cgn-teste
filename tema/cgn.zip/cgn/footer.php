
    <div class="clear"></div>

    <footer id="rodape">
        <div class="container">
            <div>
                <h3>Menu</h3>
                <?php echo do_shortcode('[menu-principal]'); ?>
            </div>
            
            <div>
                <h3>Categorias</h3>
                <?php echo do_shortcode('[menu-categorias]'); ?>
            </div>
        </div>
    </footer>

    <?php wp_footer(); ?>
    
    </body>
</html>
